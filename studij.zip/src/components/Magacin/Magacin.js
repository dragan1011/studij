import React from 'react'

import classes from './Magacin.module.css'

function Magacin() {
  return (
    <div className={classes.magacin}>Magacin</div>
  )
}

export default Magacin
import React from 'react'

import classes from './Centar.module.css'

function Centar(props) {

  const closeCentar = () => {
    props.closeCentar(false)
    props.showCentar(true)
    
  }

  return (
    <div className={classes.centar} >
      <h3 className={classes.back} onClick={closeCentar}><img alt='strelica-nazad' className={classes.img} src='./utilities/back-arrow.png' /> <span className={classes.nazad} >Nazad</span></h3>


    </div>
  )
}
export default Centar
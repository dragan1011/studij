import './App.css';
import SideMenu from './components/SideMenu/SideMenu';

function App() {
  return (
    <div className="App">
<SideMenu />
    </div>
  );
}

export default App;
